package cs2321;

//@author Christopher Valentine
//CS 2321
//Program 4
// Student No 65

public class QuickSort<E extends Comparable<E>> implements Sorter<E> {
	
	@TimeComplexity("O(n^2)")
	public void sort(E[] array) {
		
		quickSort(array, 0, array.length - 1 );
		
}
	
	public void quickSort( E[] array, int min, int max ) {
		if (min >= max) { return; }
		int left = min;
		int right = max - 1;
		E pivot = array[max];
		E temp; 
		while (left <= right) { 
		
			while (left <= right && array[left].compareTo(pivot) < 0) { left++; }
			while (left <= right && array[right].compareTo(pivot) > 0) { right--; }
			if (left <= right) {
				
				temp = array[left]; 
				array[left] = array[right]; 
				array[right] = temp;
				left++; 
				right--;
			}
		}
		// place elements in accurate position
		temp = array[left]; 
		array[left] = array[max] ; 
		array[max] = temp;
		// make recursive calls
		quickSort(array, min, left-1);
		quickSort(array, left+1, max);
	}
}