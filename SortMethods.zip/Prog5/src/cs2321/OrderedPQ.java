package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an ordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Christopher Valentine
 */

public class OrderedPQ<K,V> implements PriorityQueue<K,V> {

	private DoublyLinkedList<Entry<K,V>> pq = new DoublyLinkedList<>( );
	public DefaultComparator<K> c;
	
	protected static class PQEntry<K,V> implements Entry<K,V> {
		private K k; // key
		private V v; // value
		public PQEntry(K key, V value) {
			k = key;
			v = value;
		}
		// methods of the Entry interface
		public K getKey( ) { return k; }
		public V getValue( ) { return v; }
		// utilities not exposed as part of the Entry interface
		protected void setKey(K key) { k = key; }
		protected void setValue(V value) { v = value; }
	}
		
	
	public OrderedPQ() {
		c = new DefaultComparator<K>();
	}
	
	public OrderedPQ(Comparator<K> c) {
		this.c = (DefaultComparator<K>) c;
	}
	
	@Override
	@TimeComplexity ("O(1)")
	public int size() {
		// TODO Auto-generated method stub
		return pq.size();
	}

	@Override
	@TimeComplexity ("O(1)")
	public boolean isEmpty() {
		return pq.isEmpty();
	}

	@Override
	@TimeComplexity ("O(n)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		Entry<K,V> newest = new PQEntry<>(key, value);
		Position<Entry<K,V>> walk = pq.last( );
		// walk backward, looking for smaller key
		while (walk != null && c.compare(newest.getKey(), walk.getElement( ).getKey()) < 0) {
			
			walk = pq.before(walk);
		}
			
			if (walk == null) {
				pq.addFirst(newest); // newest key will be the smallest
			} else {
				pq.addAfter(walk, newest); // newest goes after walk
			}
		return newest;
	}

	@Override
	@TimeComplexity ("O(1)")
	public Entry<K, V> min() {		// returns the minimum value in the linked list
		if ( pq.isEmpty() ) { 
			return null; 
		}
		
		return pq.first().getElement();
	}

	@Override
	@TimeComplexity ("O(1)")
	public Entry<K, V> removeMin() {		// removes the minimum value from the list
		if (pq.isEmpty( )) {
			return null;
		}
		
		return pq.remove( pq.first() );
	}

}
