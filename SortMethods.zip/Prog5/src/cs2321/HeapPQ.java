package cs2321;


import java.util.Comparator;

import net.datastructures.*;
/**
 * A Adaptable PriorityQueue based on an heap. 
 * 
 * 
 * Assignment: #3
 * @author Christopher Valentine
 * Student No 65
 */


public class HeapPQ<K,V> implements AdaptablePriorityQueue<K,V> {
	
	protected ArrayList<Entry<K,V>> heap = new ArrayList<>( );
	/**
	 * 
	 * book class
	 *
	 * @param <K>
	 * @param <V>
	 */
	protected static class PQEntry<K,V> implements Entry<K,V> {
		private K k; // key
		private V v; // value
		public PQEntry(K key, V value) {
			k = key;
			v = value;
		}
		// methods of the Entry interface
		public K getKey( ) { return k; }
		public V getValue( ) { return v; }
		// utilities not exposed as part of the Entry interface
		protected void setKey(K key) { k = key; }
		protected void setValue(V value) { v = value; }
	} 
	private int parent(int j) { return (j-1) / 2; } // truncating division
	private int left(int j) { return 2*j + 1; }
	private int right(int j) { return 2*j + 2; }
	private boolean hasLeft(int j) { return left(j) < heap.size( ); }
	private boolean hasRight(int j) { return right(j) < heap.size( ); }
	
	protected void swap(int i, int j) {
		Entry<K,V> temp = heap.get(i);
		heap.set(i, heap.get(j));
		heap.set(j, temp);
	}
	
	private Comparator<K> comp;
	/**
	 * constructor
	 */
	public HeapPQ() {
		this(new DefaultComparator<K>( )); 
	}
	/**
	 * constructor
	 * @param c (comparator)
	 */
	public HeapPQ(Comparator<K> c) {
		comp = c;
	}
	
	protected int compare(Entry<K,V> a, Entry<K,V> b) {
		return comp.compare(a.getKey( ), b.getKey( ));
	}
	
	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (comp.compare(key,key) == 0); // see if key can be compared to itself
		} catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible key");
		}
	}
	
	/**
	 * The entry should be bubbled up to its appropriate position 
	 * @param int move the entry at index j higher if necessary, to restore the heap property
	 */
	public void upheap(int j) {
		//book method
		while (j > 0) { // continue until reaching root (or break statement)
			int p = parent(j);
			if (compare(heap.get(j), heap.get(p)) >= 0) break; // heap property verified
			swap(j, p);
			j = p; // continue from the parent's location
			}
	}
	
	/**
	 * The entry should be bubbled down to its appropriate position 
	 * @param int move the entry at index j lower if necessary, to restore the heap property
	 */
	
	public void downheap(int j){
		//book method
		while (hasLeft(j)) { // continue to bottom (or break statement)
			int leftIndex = left(j);
			int smallChildIndex = leftIndex; // although right may be smaller
		if (hasRight(j)) {
			int rightIndex = right(j);
			if (compare(heap.get(leftIndex), heap.get(rightIndex)) > 0)
				smallChildIndex = rightIndex; // right child is smaller
				}
		if (compare(heap.get(smallChildIndex), heap.get(j)) >= 0)
			break; // heap property has been restored
			swap(j, smallChildIndex);
			j = smallChildIndex; // continue at position of the child
		}

	}

	@TimeComplexity("O(1)")
	/**
	 * @TCJ
	 * variable so obvious
	 */
	@Override
	public int size() {
		// straightforward
		return heap.size();
	}

	@TimeComplexity("O(1)")
	/**
	 * @TCJ
	 * variable so obvious
	 */
	@Override
	public boolean isEmpty() {
		// straightforward
		return heap.size() <= 0;
	}

	@TimeComplexity("O(logn)")
	/**
	 * @TCJ
	 * upheap is logn runtime since it is a i/2 tree iteration
	 * therefore since we call upheap this must be also logn
	 * since this doesn't add any loops that would increase
	 * time complexity
	 */
	@Override
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		//book method
		Entry<K,V> newest = new PQEntry<>(key, value);
		heap.addLast(newest); // add to the end of the list
		upheap(heap.size() - 1); // upheap newly added entry
		return newest;
	}

	@TimeComplexity("O(1)")
	/**
	 * @TCJ
	 * We already know position of min so O(1) no loops
	 */
	@Override
	public Entry<K, V> min() {
		// book method
		if (heap.isEmpty()) {	
		return null;
		}
		return heap.get(0);
	}

	@TimeComplexity("O(logn")
	/**
	 * @tcj
	 * downheap is logn so this must be logn since no new loops
	 * 
	 */
	@Override
	public Entry<K, V> removeMin() {
		if (heap.isEmpty( )) {
			return null;
		}
		Entry<K,V> answer = heap.get(0);
		swap(0, heap.size( ) - 1); // put minimum item at the end
		heap.remove(heap.size( ) - 1); // and remove it from the list;
		downheap(0); // then fix new root
		return answer;
		}

	@Override
	@TimeComplexity("O(nlogn)")
	/**
	 * @TCJ
	 * forloop over n items therefore o(n) for that part
	 * then call downheap which is logn
	 * n * logn
	 * @param entry
	 * @throws IllegalArgumentException
	 */
	public void remove(Entry<K, V> entry) throws IllegalArgumentException { 
		int entryIndex = -1;
		K entryKey = entry.getKey();
		for(int i = 0; i < heap.size(); i++) {
			
			if (entryKey == heap.get(i).getKey()) {
				entryIndex = i;
			}
			
		}
		if(entryIndex < 0) {
			throw new IllegalArgumentException();
		}
		
		heap.remove(entryIndex);
		downheap(entryIndex);
		
	}

	@TimeComplexity("O(logn)")
	/**
	 * @TCJ
	 * no new loops calls downheap therefore logn
	 * @param entry
	 * @param key
	 * @throws IllegalArgumentException
	 */
	@Override
	public void replaceKey(Entry<K, V> entry, K key) throws IllegalArgumentException {
		V value = entry.getValue();
		remove(entry);
		insert(key, value);
		downheap(0);
	}

	@TimeComplexity("O(logn)")
	/**
	 * @TCJ
	 * no new loops therefore logn
	 * @param entry
	 * @param value
	 * @throws IllegalArgumentException
	 */
	@Override
	public void replaceValue(Entry<K, V> entry, V value) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		K key = entry.getKey();
		remove(entry);
		insert(key, value);
		downheap(0);
	}
	
	


}
