package cs2321;



public class HeapPQSort<K extends Comparable<K>> extends PQSort<K> implements Sorter<K> {
	/**
	 * sort - Perform an PQ sort using a Heap
	 * @param array - Array to sort
	 */
	@TimeComplexity("O(n log(n))")
	public void sort(K[] array){
		super.sort(array, new HeapPQ<K,K>());
	}
}
