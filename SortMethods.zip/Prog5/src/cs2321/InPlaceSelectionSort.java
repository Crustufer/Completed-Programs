package cs2321;

//@author Christopher Valentine
//CS 2321
//Program 4
// Student No 65

public class InPlaceSelectionSort<K extends Comparable<K>> implements Sorter<K> {

	@TimeComplexity("O(n^2)")
	public void sort(K[] array) {
		DefaultComparator<K> c = new DefaultComparator<>();
		int minNum;

        for (int j = 0; j < array.length; j++ ) {
            minNum = j;

            // find minimum element in array
            for (int i = j + 1; i < array.length; i++ ) {

                if (c.compare( array[i],  array[minNum] ) < 0) {
                    minNum = i;
                }
            }
        
            K temp = array[j];
            array[j] = array[ minNum];
            array[minNum] = temp;
            
        }
	}
}
