package cs2321;

import java.util.Iterator;


import net.datastructures.List;

public class ArrayList<E> implements List<E> {
	private int curSize;
	private int maxSize = 16;
	private E[] data;
	

	@SuppressWarnings("unchecked")
	public ArrayList() {
		this.curSize = 0;
		data = (E[]) new Object[maxSize];
		
	}

	@TimeComplexity("O(1)")
	@Override
	public int size() { return curSize; }

	@TimeComplexity("O(1)")
	@Override
	public boolean isEmpty() { return curSize == 0; }

	@TimeComplexity("O(1)")
	@Override
	public E get(int index) throws IndexOutOfBoundsException {
		checkIndex(index, curSize);
		return data[index];
	}
	@TimeComplexity("O(1)")
	private void checkIndex(int index, int size) throws IndexOutOfBoundsException {
		if ( index < 0 || index >= size) { //if (index < 0 || index  >= size)
			throw new IndexOutOfBoundsException("Illegal Index");
		}
	}
	
	@TimeComplexity("O(1)")
	@Override
	public E set(int index, E value) throws IndexOutOfBoundsException {
		checkIndex(index, curSize);
		E temp = data[index];
		data[index] = value;
		return temp;
	}

	@TimeComplexity("O(n)") //depends on if double it is called
	@Override
	public void add(int index, E value) throws IndexOutOfBoundsException {
		checkIndex(index, curSize+1);
		if(curSize == maxSize) {
			doubleIt();
		}
		for (int i = curSize - 1; i >= index; i-- ) {
			data[i+1] = data[i];
		}
		data[index] = value;
		curSize++;
	}
	@TimeComplexity("O(n)")
	@SuppressWarnings("unchecked")
	private void doubleIt() {
		E[] temp;
		temp = (E[]) new Object[2 * maxSize];
		for(int i = 0; i < curSize; i++) {
			temp[i] = data[i];
		}
		data = temp;
		maxSize *= 2;
	}
	
	@TimeComplexity("O(n)")
	@Override
	public E remove(int index) throws IndexOutOfBoundsException {
		checkIndex(index, curSize);
		E temp = data[index];
		for (int i = index; i < curSize - 1; i++ ) {
			data[i] = data[i+1];
		}
		data[curSize - 1] = null;
		curSize--;
		return temp;
	}

	
	@Override
	public Iterator<E> iterator() {
		return new ArrayIterator();
	}

	@TimeComplexity("O(n) to O(n^2)") //depends on if doubleIt is called
	public void addFirst(E value)  {
		if (curSize == maxSize) {
			doubleIt();
		}
		for (int i = curSize - 1; i >= 0; i-- ) {
			data[i+1] = data[i];
		}
		data[0] = value;
		curSize++;
	}
	
	@TimeComplexity("O(1) to O(n)") //depends on if doubleIt is called
	public void addLast(E value)  {
		if (curSize == maxSize) {
			doubleIt();
		}
		data[curSize] = value;
		curSize++;
		
	}
	
	@TimeComplexity("O(n)")
	public E removeFirst() throws IndexOutOfBoundsException {
		checkIndex(0, curSize);
		E temp = data[0];
		for (int i = 0; i < curSize - 1; i++ ) {
			data[i] = data[i+1];
		}
		data[curSize - 1] = null;
		curSize--;
		return temp;
	}
	
	@TimeComplexity("O(1)")
	public E removeLast() throws IndexOutOfBoundsException {
		checkIndex(0, curSize);
		E temp = data[curSize - 1];
		data[curSize - 1] = null;
		return temp;
	}
	
	@TimeComplexity("O(1)") //depends on if double it is called
	// Return the capacity of array, not the number of elements.
	// Notes: The initial capacity is 16. When the array is full, the array should be doubled. 
	public int capacity() {
		if (curSize == maxSize) {
			doubleIt();
		}
		return maxSize;
	}
	private class ArrayIterator implements Iterator<E> {
		private int position = 0;

		@Override
		public boolean hasNext() {
			return position < curSize;
		}

		@Override
		public E next() {
			return data[position++];
		}
		
	}
	public static void main(String[] args ) {
	}
}
