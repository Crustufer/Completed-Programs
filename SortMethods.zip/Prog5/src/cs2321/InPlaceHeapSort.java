package cs2321;


//@author Christopher Valentine
//CS 2321
//Program 4
// Student NO 65

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {

	DefaultComparator<K> c = new DefaultComparator<>();
	
	@TimeComplexity("O(nlog(n) )")
	
	public void sort(K[] array) {
	
		
		int size = array.length;
		// build heap
		for (int i = size / 2 - 1; i >= 0; i--) {
            heapify(array, size, i);
		}
		
		for (int i = size - 1; i >= 0; i -- ) {
			K temp = array[0]; 
            array[0] = array[i]; 
            array[i] = temp;
           
            heapify(array, i, 0);
		}
		
	}
	public void heapify( K[] arr, int size, int index ) {
		
		int max = index;
        int l = 2 * index + 1;  // left = 2*i + 1 
        int r = 2 * index + 2;  // right = 2*i + 2 
        
        // if statements to find max
        if (l < size && c.compare(arr[l], arr[max]) > 0) {
            max = l;
        }
        if (r < size && c.compare(arr[r], arr[max]) > 0) {
            max = r;
        }
        // places max in the correct place
        if (max != index ) {
        	K temp = arr[index];
        	arr[index] = arr[max];
        	arr[max] = temp;
        	heapify(arr, size, max);
        }
	}

}
