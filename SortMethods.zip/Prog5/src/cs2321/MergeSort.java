package cs2321;

import java.util.Arrays;

//@author Christopher Valentine
//CS 2321
//Program 4
// Student No 65

public class MergeSort<E extends Comparable<E>> implements Sorter<E> {
	
	@TimeComplexity("O(nlog(n) )")
	public void sort(E[] array) {
		int n = array.length;
		if (n < 2) { return; } 
		//divide
		int mid = n/2;
		E[ ] part1 = Arrays.copyOfRange( array, 0, mid ); 
		E[ ] part2 = Arrays.copyOfRange( array, mid, n ); 
		sort(part1); 
		sort(part2); 
		// merge results
		merge(part1, part2, array); 
        }

	public static <E> void merge(E[] part1, E[] part2, E[] arr) {
		DefaultComparator<E> c = new DefaultComparator<>();
		int i = 0;
		int j = 0;
		while(i + j < arr.length) {
			
			// if statements to place elements in order
			if (j == part2.length || (i < part1.length && c.compare( part1[ i ], part2[j]) < 0 )) {
				arr[i + j] = part1[i++];
				
			} else {
				arr[i + j] = part2[j++];
			}
		}
		
	}

}

