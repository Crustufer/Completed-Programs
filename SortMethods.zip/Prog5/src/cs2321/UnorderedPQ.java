package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an Unordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Christopher Valentine
 */

public class UnorderedPQ<K,V> implements PriorityQueue<K,V> {
	
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<>( );

	
	protected static class PQEntry<K,V> implements Entry<K,V> {
		private K k; // key
		private V v; // value
		public PQEntry(K key, V value) {
			k = key;
			v = value;
		}
		// methods of the Entry interface
		public K getKey( ) { return k; }
		public V getValue( ) { return v; }
		// utilities not exposed as part of the Entry interface
		protected void setKey(K key) { k = key; }
		protected void setValue(V value) { v = value; }
	}
	
	@TimeComplexity("O(1)")
	protected boolean checkKey(K key) throws IllegalArgumentException {
		try {
			return (comp.compare(key,key) == 0); // see if key can be compared to itself
		} catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible key");
		}
	}
	
	@TimeComplexity("O(1)")
	protected int compare(Entry<K,V> a, Entry<K,V> b) {
		return comp.compare(a.getKey( ), b.getKey( ));
	}
	
	@TimeComplexity("O(n)")
	private Position<Entry<K,V>> findMin( ) { // only called when nonempty
		Position<Entry<K,V>> small = list.first( );
		for (Position<Entry<K,V>> walk : list.positions( ))
			if (compare(walk.getElement( ), small.getElement( )) < 0)
				small = walk; // found an even smaller key
		return small;
		}
	
	private Comparator<K> comp;

	public UnorderedPQ() {
		//TODO implement this method
		this(new DefaultComparator<K>( )); 
	}
	
	public UnorderedPQ(Comparator<K> c) {
			//TODO implement this method
		comp = c;
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		// TODO Auto-generated method stub
		return list.size( );
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		if ( list.size() <= 0 ) {
			return true;
		}
		return false;
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key); // auxiliary key-checking method (could throw exception)
		Entry<K,V> newest = new PQEntry<>(key, value);
		list.addLast(newest);
		return newest;
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> min() {
		if (list.isEmpty( )) return null;
		return findMin( ).getElement( );
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> removeMin() {
		// TODO Auto-generated method stub
		if (list.isEmpty( )) return null;
		return list.remove(findMin( ));
	}
	
	

}
