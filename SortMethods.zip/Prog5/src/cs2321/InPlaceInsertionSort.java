package cs2321;

//@author Christopher Valentine
//CS 2321
//Program 4
// Student No 65

public class InPlaceInsertionSort<K extends Comparable<K>> implements Sorter<K> {
	@TimeComplexity("O(n^2)")
	
	public void sort(K[] array) {
		// iterate through array
		for ( int i = 0; i < array.length; i++ ) {
            K comp = array[ i ]; // value to compare
            
            int j = i - 1;
            while ( j >= 0 && array[ j ].compareTo( comp ) > 0 ) { // shift elements
                array[ j + 1 ] = array [ j ];
                j = j - 1;
            }
            // place
            array[ j + 1 ] = comp;
        }

	}

}
