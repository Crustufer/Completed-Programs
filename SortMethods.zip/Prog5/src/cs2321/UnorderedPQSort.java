package cs2321;

public class UnorderedPQSort<K extends Comparable<K>> extends PQSort<K> implements Sorter<K>  {

	@Override
	public void sort(K[] array) {
		super.sort(array, new UnorderedPQ<K,K>());
	}

}
