import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class PirateTalk extends AbstractPirateTalk {

    public class VocabRule implements VocabRuleInterface {
        private String englishWord = "";
        private String pirateTrabslation = "";

        @Override
        public String getEnglish() {
            return englishWord;
        }

        @Override

        public String getPirate() {
            return pirateTrabslation;
        }
        public VocabRule ( String englishWord, String pirateTrabslation) {
            this.englishWord = englishWord;
            this.pirateTrabslation = pirateTrabslation;
        }
    }
    ArrayList< VocabRuleInterface > rules = new ArrayList< VocabRuleInterface >( );
    ArrayList<String> English = new ArrayList<>();
    ArrayList<String> Pirate = new ArrayList<>();
        @Override
    public boolean loadDictionary( String filename ) {
            PirateTalk argg = new PirateTalk();
            int dictionary;
            boolean value = false;
            String temp;
            try ( Scanner scan = new Scanner( new File( filename ) ) ) {
                value = true;
                dictionary = scan.nextInt();
                for (int i = 0; i < dictionary; i++) {
                    String line = scan.nextLine();
                    temp = line.substring(0, line.indexOf( ":" ) + 1 );
                    String englishWord = temp.replace(":", "");
                    String pirateWord = line.substring(line.indexOf( ":" ) + 1 ).trim( );
                    English.add( englishWord );
                    Pirate.add( pirateWord );
                }
            }
            catch ( IOException e) {
                e.printStackTrace();
                System.out.println("File Not Found: " + filename);
            }
            return value;
        }


    public String translateWord( String word ) {
        int wordNumber = -1;
        String wordCap = "a";
        String pirateWord = "";
        String ing = "ing";
        String v = "'";
        if ( word == null) {
            pirateWord = "Splice the mainbrace!";
            return pirateWord;
        }
        if ( word.equals("") ) {
            pirateWord = "Blimey!";
            return pirateWord;
        }
        if (Character.isUpperCase(word.charAt(0)) && !word.equals("") ) {
            wordCap = word;
            word = word.substring(0, 1).toLowerCase() + word.substring(1);
        }
        if ( word.endsWith(".") || word.endsWith("!")) {
            String subWord = word.substring( 0, word.length() - 1 );
            pirateWord = subWord;
            for (int i = 0; i < English.size(); i++) {
                if (English.get(i).equals(subWord)) {
                    wordNumber = i;
                    pirateWord = Pirate.get(wordNumber);
                }
            }
        }
        for (int i = 0; i < English.size(); i++) {
            if (English.get(i).equals(word)) {
                wordNumber = i;
                pirateWord = Pirate.get(wordNumber);
            }
        }

        if ( wordNumber == -1 ) {
            pirateWord = word;
            if ( pirateWord.toLowerCase().contains(ing.toLowerCase())) {
                pirateWord = pirateWord.substring(0, pirateWord.length() - 1) + v;
            }
            for ( int i = 0; i < pirateWord.length(); i++) {
                if ( pirateWord.charAt(i) == 'v') {
                    pirateWord = pirateWord.substring(0, i) + v + pirateWord.substring(i + 1);
                }
            }
        }

        if (Character.isUpperCase(wordCap.charAt(0))) {
            pirateWord = pirateWord.substring(0, 1).toUpperCase() + pirateWord.substring(1);
        }

        return pirateWord;
    }

    public String translatePassage( String passage ) {
        String result = "";
        if ( passage == null ) {
            result = "Splice the mainbrace!";
            return result;
        }
        Scanner scan = new Scanner( passage );
        if ( passage.equals("") ) {
            result = "Blimey!";
            return result;
        }
        while ( scan.hasNext( ) ) {
            String word = scan.findInLine ( "(\\w+)|([\\p{P}]+)|(\\s+)" );
            result += translateWord( word );
        }
        scan.close( );
        return result;
    }

    public static void main ( String [] args ) {
        PirateTalk pi = new PirateTalk();
        Scanner scan = new Scanner( System.in );
        pi.loadDictionary("C:\\Users\\chris\\Desktop\\PirateTalk\\dictionary.txt");

        System.out.println("English to Pirate ");
        String endPhrase = scan.nextLine();
        System.out.println(pi.translatePassage(endPhrase));
    }

}