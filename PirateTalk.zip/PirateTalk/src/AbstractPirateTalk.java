import java.util.ArrayList;
import java.util.Scanner;

/**
 *  An abstract class providing some functionality to
 *  translate English to Pirate.
 *
 *  @author Leo Ureel
 *  CS1122 R02, Spring 2018
 *
 *  Date Last Modified: 31 January 2018
 */
public abstract class AbstractPirateTalk {
   // Implement this interface as an inner class.
   protected interface VocabRuleInterface {
      public String getEnglish( );
      public String getPirate( );
   }

   // Use this to store the translation rules.
   protected ArrayList< VocabRuleInterface > rules = new ArrayList< VocabRuleInterface >( );

   /**
    * Given a filename, loads the translation rules.
    *
    * @param filename - the name of the translation file to load.
    *
    * @return true if the load is successful.
    */
   public abstract boolean loadDictionary( String filename );

   /**
    * Given an English word, returns the pirate equivalent.
    *
    * @param word - an English word.
    *
    * @return a pirate equivalent to the provided English word.
    */
   public abstract String translateWord( String word );

   /**
    * Given a passage in English, returns the pirate equivalent.
    *
    * NOTE: This gets you most of the way there,
    * but it is not sufficient to meet the requirements.
    *
    * You must find a way to extend the behavior of this method.
    *
    * @param passage - a string of English words.
    *
    * @return a pirate phrase that is equivalent
    *         to the provided English passage.
    */
   public String translatePassage( String passage ) {
      Scanner scan = new Scanner( passage );
      String result = "";
      while ( scan.hasNext( ) ) {
         String word = scan.findInLine( "(\\w+)|([\\p{P}]+)|(\\s+)" );
         result += translateWord( word );
      }
      scan.close( );
      return result;
   }

   /**
    * This method provides several simple tests.
    *
    * NOTE: You must pass the -ea argument to the vm for this method to work.
    *
    * @param filename - name of the dictionary to load.
    */
   public void tests( String filename ) {
      boolean loaded = loadDictionary( filename );
      assert loaded;
      assert translateWord( "hello" ).equals( "ahoy" );
      assert translateWord( "Hello" ).equals( "Ahoy" );
      assert translateWord( "coins" ).equals( "pieces of eight" );
      assert translateWord( "talking" ).equals( "blabberin'" );
      assert translateWord( "girl" ).equals( "lass" );
      assert translateWord( "." ).equals( ". Arrr." );
      assert translateWord( "!" ).equals( "! Shiver me timbers!" );
      assert translateWord( "stop" ).equals( "belay" );
      assert translateWord( null ).equals( "Splice the mainbrace!" );
      assert translateWord( "" ).equals( "Blimey!" );

      assert translatePassage( "Hello! I am Professor Leo." ).equals( "Ahoy! Shiver me timbers! I be Cap'n Leo. Arrr." );
      assert translatePassage( "" ).equals( "Blimey!" );
      assert translatePassage( null ).equals( "Splice the mainbrace!" );
      assert translatePassage( "I am happy!" ).equals( "I be grog-filled! Shiver me timbers!" );
      assert translatePassage( "This is a test." ).equals( "This be a briny test. Arrr." );
      assert translatePassage( "The quick brown fox jumps over the lazy dog." ).equals( "Th' smart brown fox jumps o'er th' lazy cur. Arrr." );
      assert translatePassage( "Time to eat." ).equals( "Time t' gobble. Arrr." );
      assert translatePassage( "A mother's arms are made of tenderness and children sleep soundly in them." ).equals( "A briny dear ol' mum, bless her black soul's arms be made o' tenderness an' sprogs take a caulk soundly in them. Arrr." );
      assert translatePassage( "The student spent a lot of money of books!" ).equals( "Th' swab spent a briny lot o' booty o' books! Shiver me timbers!" );
      assert translatePassage( "You can call me anything you want. Just do not call me late for dinner!" ).equals( "Ye can call me anythin' ye be needin'. Arrr. Jus' do nah call me late for grub! Shiver me timbers!" );
   } // END OF METHOD

} // END OF CLASS: AbstractPirateTalk