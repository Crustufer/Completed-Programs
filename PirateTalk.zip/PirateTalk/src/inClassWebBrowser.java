import javafx.application.Application;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class inClassWebBrowser extends Application{

    public static void main ( String [] args ) {
        launch (args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("CS 1122 WebBrowser");
        BorderPane pane = new BorderPane();
        Scene scene = new Scene( pane );

        //Statusbar
        HBox statusbarArea = new HBox(10);
        statusbarArea.setPadding( new Insets( 10 ));
        Label statusbar = new Label("The quick brown fox jumped over tha lazy dog");
        statusbarArea.getChildren().addAll( statusbar );
        pane.setBottom(statusbarArea);

        //Web Browser
        WebView view = new WebView();
        WebEngine engine = view.getEngine();
        engine.setOnStatusChanged(event -> {
           statusbar.setText(event.getData());
        });


        engine.load("http://www.mtu.edu");
        pane.setCenter(view);

        //Toolbar
        HBox toolbarArea = new HBox (10);
        toolbarArea.setPadding(new Insets(10));

        Button backButton = new Button("<");
        backButton.setOnAction(event -> {
            if (engine.getHistory().getCurrentIndex() > 0) {
                engine.getHistory().go(-1);
            }
        });

        Button nextButton = new Button(">");
        nextButton.setOnAction(event -> {
            if (engine.getHistory().getCurrentIndex() < engine.getHistory().getEntries().size() - 1) {
                engine.getHistory().go(1);
            }
        });

        Button helpButton = new Button("?");
        helpButton.setOnAction(event -> {
            engine.load("C:///Users/chris/Desktop/PirateTalk/src/help");
        });

        TextField urlEntry = new TextField();
        urlEntry.setOnAction(event -> {
            String url = urlEntry.getText();
            if (! url.startsWith("http://")) {
                url = "http://" + url;
            }
            engine.load(url);
        });

        toolbarArea.getChildren().addAll(backButton, nextButton, urlEntry, helpButton);
        toolbarArea.setHgrow(urlEntry, Priority.ALWAYS);

        engine.getLoadWorker().stateProperty().addListener(
                (ov, oldState, newState) -> {
                    if (newState == State.SUCCEEDED) {
                        //primaryStage.setTitle(engine.getLocation());
                        urlEntry.setText(engine.getLocation());
                    }
                });
        primaryStage.titleProperty().bind(engine.titleProperty());

        pane.setTop(toolbarArea);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
