package cs2321;

import net.datastructures.*;


/**
 * 
 * @author Christopher Valentine
 * Student No 65
 * @param <K>
 * @param <V>
 */
public class HashMap<K, V> extends AbstractMap<K,V> implements Map<K, V> {
	
	/* use an array of UnorderedMap<K,V> to store data
	 * 
	 */
	private UnorderedMap<K,V>[]  table;
	int 	size;  // number of mappings(entries) 
	int 	capacity; // The size of the hash table. 
	int     DefaultCapacity = 17; //The default hash table size 
	
	/* keep the load factor at <= 0.75.
	 * if the load factor becomes too large
	 * then double the table, rehash the entries, and put them into a new spot
	 */
	
	double  loadfactor= 0.75;  
	
	/**
	 * Constructor that takes a hash size
	 */
	
	public HashMap(int hashtablesize) {
		capacity = hashtablesize;
		table = (UnorderedMap<K,V>[]) new UnorderedMap[capacity];
	}
	
	/**
	 * Constructor that takes no argument
	 * Initialize the hash table with default hash table size: 17
	 */
	public HashMap() {
		this(17);
	}
	

	private int hashValue(K key) {
		return Math.abs(key.hashCode()) % capacity;
	}
	
	/*
	 * method tests if the table was double and rehashed
	 */
	@TimeComplexity("O(1)")
	public int tableSize() {
		return capacity;
	}
	
	@TimeComplexity("O(1)")
	@Override
	public int size() {
		return size;
	}
	
	@TimeComplexity("O(1)")
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@TimeComplexity("O(n)")
	@Override
	public V get(K key) {
		UnorderedMap<K,V> bucket = table[hashValue(key)];
		if (bucket == null) {
			return null;
		}	
		return bucket.get(key);
	}

	@TimeComplexity("O(n)")
	@Override
	public V put(K key, V value) {
		UnorderedMap<K,V> bucket = table[hashValue(key)];
		
		if(bucket == null) {
			bucket = table[hashValue(key)] = new UnorderedMap<K,V>();
		}
		int oldSize = bucket.size();
		V temp = bucket.put(key, value);
		size += (bucket.size() - oldSize);
		if((double)(size/capacity) > loadfactor) {
			resize();
		}
		return temp;
	}
	
	@TimeComplexity("O(n)")
	@SuppressWarnings("unchecked")
	private void resize() {
		ArrayList<Entry<K,V>> buff = new ArrayList<>();
		for (Entry<K,V> e : entrySet()) {
			buff.addLast(e);
		}
		capacity *= 2;
		table = (UnorderedMap<K,V>[]) new UnorderedMap[capacity];
		size = 0;
		for(Entry<K,V> e : buff) {
			put(e.getKey(),e.getValue());
		}
	}
	
	@TimeComplexity("O(n)")
	@Override
	public V remove(K key) {
		UnorderedMap<K,V> bucket = table[hashValue(key) ];
		if (bucket == null) {
			return null;
		}
		int oldSize = bucket.size();
		V temp = bucket.remove(key);
		size -= (oldSize-bucket.size());
		return temp;
	}

	@TimeComplexity("O(n^2)")
	@Override
	public Iterable<Entry<K,V>> entrySet() {
		DoublyLinkedList<Entry<K,V>> buff = new DoublyLinkedList<>();
		for (int i = 0; i < capacity; i++) {
			if (table[i] != null) {
				for(Entry<K,V> entry : table[i].entrySet()) {
					buff.addLast(entry);
				}
			}
		}
		return buff;
	}
}
