package cs2321;
import java.util.Iterator;

import net.datastructures.Position;
import net.datastructures.PositionalList;
/**
 * 
 * @author Christopher Valentine
 *student no 65
 * @param <E>
 */


public class DoublyLinkedList<E> implements PositionalList<E> {

	//class to define nodes
	private static class Node<E> implements Position<E> {
		// instance variables linked to the node class
		private E element; 
		private Node<E> prev; 
		private Node<E> next; 	
		
		public Node(E e, Node<E> p, Node<E> n) {
			element = e;
			prev = p;
			next = n;
		}
		
		public E getElement( ) throws IllegalStateException { 
			if( next == null) {
				throw new IllegalStateException("Position no longer valid");
			}
			
			return element; 
		}
		
		public void setElement(E value) {
			this.element = value;
		}
		
		public Node<E> getPrev( ) { 
			return prev; 
		}
		
		public Node<E> getNext( ) { 
			return next; 
		}
		
		public void setPrev(Node<E> p) { prev = p; }
		
		public void setNext(Node<E> n) { next = n; }
	}
	
	private Node<E> header;
	private Node<E> trailer;
	private int size = 0; 		//number of elements
	
	public DoublyLinkedList() {
		header = new Node<>(null, null, null); 		
		trailer = new Node<>(null, header, null);
		header.setNext(trailer);
	}

	//Returns the number of elements in the list
	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	public E getFirstElement() throws IllegalArgumentException {
		return (header.getNext().getElement());
	}
	

	@Override
	@TimeComplexity("1")
	public boolean isEmpty() {
		return (size == 0);
	}


	@Override
	@TimeComplexity("n")
	public Position<E> first() {
		if (isEmpty( )) {
			return null;
		}
		return position(header.getNext( )); //First element is after the header
	}


	@Override
	@TimeComplexity("O(n)")
	public Position<E> last() {
		if (isEmpty( )) {
			return null;
		}
		return position(trailer.getPrev( )); // last element is directly before the trailer
	}


	@Override
	@TimeComplexity("O(n)")
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		Node<E> node = convert(p);
		if(node.getPrev() == header ) {
			return null;
		} else
		{
			return position(node.getPrev());
		}
	}


	@Override
	@TimeComplexity("O(n)")
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = convert(p);
		if(node.getNext() == trailer) {
			return null;
		} else {
			return position(node.getNext());
		}
	}


	@Override
	@TimeComplexity("O(1)")
	public Position<E> addFirst(E e) {
		addBetween(e, header, header.getNext( )); // place after the header
		return first();
	}


	@Override
	@TimeComplexity("O(1)")
	public Position<E> addLast(E e) {
		// TODO Auto-generated method stub
		addBetween(e, trailer.getPrev( ), trailer); // place before the trailer
		return last();
	}


	@Override
	@TimeComplexity("O(1)")
	public Position<E> addBefore(Position<E> p, E e)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = convert(p);
		  
		addBetween(e, node.getPrev(), node);
		return before(p);
	}


	@Override
	@TimeComplexity("O(1)")
	public Position<E> addAfter(Position<E> p, E e)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = convert(p);
		addBetween(e, node, node.getNext());
		return after(p);
	}

	@TimeComplexity("O(1)")
	private void addBetween(E e, Node<E> prevNode, Node<E> nextNode) {
		Node<E> newest = new Node<>(e, prevNode, nextNode);
		prevNode.setNext(newest);
		nextNode.setPrev(newest);
		size++;
	}
	
	// method to convert type
	private Node<E> convert( Position<E> p) {
		if( p instanceof Node ) {
			return (Node<E>) p;
		} else {
			throw new IllegalArgumentException();
		}
	}
	@TimeComplexity("O(n)")
	public Position<E> position(Node<E> node) {
		if( node == header || node == trailer) {
			return null;
		}
		return node;
	}



	@Override
	@TimeComplexity("O(n)")
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = convert(p);
		E temp = node.getElement();
		node.setElement(e);
		return temp;
	}


	@Override
	@TimeComplexity("O(1)")
	public E remove(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		Node<E> node = convert(p);
		
		Node<E> previous = node.getPrev( );
		Node<E> next = node.getNext( );
		previous.setNext(next);
		next.setPrev(previous);
		size--;
		
		//helping garbage collection
		E removable = node.getElement();
		node.setElement(null); 
		node.setNext(null);
		node.setPrev(null);
		return removable;
	}


	@Override
	@TimeComplexity("O(1)")
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new ListIterator();
	}


	@Override
	public Iterable<Position<E>> positions() {
		return new PositionIterable();
	}
	

	@TimeComplexity("O(1)")
	public E removeFirst() throws IllegalArgumentException {
		E temp = (header.getNext()).getElement();
		
		header.setNext(header.getNext().getNext());
		header.getNext().setPrev(header);
		
		return temp;
	}

	
	@TimeComplexity("O(1)")
	public E removeLast() throws IllegalArgumentException {
		// TODO Auto-generated method stub
			E temp = (trailer.getPrev()).getElement();
				
			trailer.setPrev(trailer.getPrev().getPrev());
			trailer.getPrev().setNext(trailer);
				
			return temp;
	}
	
	//helper class for the iterator method
	private class ListIterator implements Iterator<E>
	{
		Iterator<Position<E>> posIterator = new PositionIterator( );
		Node<E> cursor = header.getNext();

		
		@Override
		public boolean hasNext() {
			return cursor != trailer;
		}

		@Override
		public E next() {
			E cur = cursor.getElement();
			cursor = cursor.getNext();
			return cur;
		}
		
		public void remove( ) { 
			posIterator.remove( );
			}
	}
	//helper class for position
	public class PositionIterator implements Iterator<Position<E>> {
		public Position<E> cursor = first( );
		public Position<E> recent = null;
		public boolean hasNext( ) { 
			return (cursor != null); 
		}
		public Position<E> next( ) {
			recent = cursor;
			cursor = after(cursor);
			return recent;
		}
		public void remove( ) throws IllegalStateException {
			if (recent == null) throw new IllegalStateException("nothing to remove");	
			DoublyLinkedList.this.remove(recent);
			recent = null;
		}
	}
	
	public class PositionIterable implements Iterable<Position<E>> {
		 public Iterator<Position<E>> iterator( ) { 
			 return new PositionIterator( ); 
			 }
		}

}
