package cs2321;

import java.io.*;
import java.util.Scanner;
import net.datastructures.*;

/* CS2321 Project: The Labyrinth
 *
 * Do NOT change the setupLabyrinth function.
 *         
 * Implement the dfsPath, bfsPath, shortestPath, and totalPathDistance functions below.
 *
 *@author Christopher Valentine
 * Student no 65
 */
public class Labyrinth {
	public static final int WALL = 1;
	public static final String PARSE_CHARACTER = ",";

	private Graph<RoomCoordinate, Walkway> mGraph;
	private int mWidth = -1;
	private int mHeight = -1;

	public Labyrinth(String aFileName) {

		mGraph = setupLabyrinth(aFileName);

	}

	// Width of the labyrinth # of squares
	public int getWidth() {
		return mWidth;
	}

	// Height of the labyrinth # of squares
	public int getHeight() {
		return mHeight;
	}

	/*
	 * Create the graph based on the maze in the input file
	 */
	public Graph<RoomCoordinate, Walkway> setupLabyrinth(String aFileName) {
		Scanner lFile = null;
		try {
			lFile = new Scanner(new File(aFileName));
			lFile.useDelimiter(",\n");
		} catch (FileNotFoundException eException) {
			System.out.println(eException.getMessage());
			eException.printStackTrace();
			System.exit(-1);
		}

		Graph<RoomCoordinate, Walkway> lGraph = new AdjListGraph<RoomCoordinate, Walkway>();

		try {
			int lXSize = 0;
			int lYSize = 0;
			if (lFile.hasNext()) {
				String[] lDimensions = lFile.nextLine().split(PARSE_CHARACTER);
				lXSize = Integer.parseInt(lDimensions[0]);
				lYSize = Integer.parseInt(lDimensions[1]);
			}

			mWidth = lXSize;
			mHeight = lYSize;

			/* Create all the room coordinates */
			Vertex<?>[][] lVertices = new Vertex<?>[lXSize][lYSize];
			for (int lYIndex = 0; lYIndex < lYSize; lYIndex++) {
				for (int lXIndex = 0; lXIndex < lXSize; lXIndex++) {
					RoomCoordinate lNextRoomCoordinate = new RoomCoordinate(lXIndex, lYIndex);
					Vertex<RoomCoordinate> lNextRoom = lGraph.insertVertex(lNextRoomCoordinate);
					lVertices[lXIndex][lYIndex] = lNextRoom;
				}
			}

			for (int lYIndex = 0; lYIndex < lYSize; lYIndex++) {
				String[] lWalls = lFile.nextLine().split(PARSE_CHARACTER);
				for (int lXIndex = 0; lXIndex < lXSize; lXIndex++) {
					if (Integer.parseInt(lWalls[lXIndex]) != WALL) {
						Vertex<RoomCoordinate> lVertex1 = (Vertex<RoomCoordinate>) lVertices[lXIndex][lYIndex];
						Vertex<RoomCoordinate> lVertex2 = (Vertex<RoomCoordinate>) lVertices[lXIndex][lYIndex - 1];

						Walkway lNewWalkway = new Walkway(
								lVertex1.getElement().toString() + lVertex2.getElement().toString(),
								Integer.parseInt(lWalls[lXIndex]));
						lGraph.insertEdge(lVertex1, lVertex2, lNewWalkway);
					}
				}
			}

			for (int lYIndex = 0; lYIndex < lYSize; lYIndex++) {
				String[] lWalls = lFile.nextLine().split(PARSE_CHARACTER);
				for (int lXIndex = 0; lXIndex < lXSize; lXIndex++) {
					if (Integer.parseInt(lWalls[lXIndex]) != WALL) {
						Vertex<RoomCoordinate> lVertex1 = (Vertex<RoomCoordinate>) lVertices[lXIndex][lYIndex];
						Vertex<RoomCoordinate> lVertex2 = (Vertex<RoomCoordinate>) lVertices[lXIndex - 1][lYIndex];

						Walkway lNewWalkway = new Walkway(
								lVertex1.getElement().toString() + lVertex2.getElement().toString(),
								Integer.parseInt(lWalls[lXIndex]));
						lGraph.insertEdge(lVertex1, lVertex2, lNewWalkway);
					}
				}
			}
		} catch (Exception eException) {
			System.out.println(eException.getMessage());
			eException.printStackTrace();
			System.exit(-1);
		}

		return lGraph;
	}

	/**
	 * Complete the dfsPath function by implementing a Depth First Search algorithm
	 * to find a path from start to end. At each vertex, the adjacent edges shall be
	 * searched in the order of NORTH, EAST, SOURTH and WEST.
	 * 
	 * @param start an RoomCoordinate object represents the start location, this
	 *              object does not exist in the graph
	 * @param end   an RoomCoordinate object represents the start location, this
	 *              object does not exist in the graph
	 * @return Return the sequence of edges traversed in order to get from the start
	 *         to the finish locations. If there is NO path, do NOT return null.
	 *         Return an empty sequence.
	 */
	@TimeComplexity("O( n + m )")
	public Iterable<Edge<Walkway>> dfsPath(RoomCoordinate start, RoomCoordinate end) {
		HashMap<Vertex<RoomCoordinate>, Boolean> visited = new HashMap<>((int) ((double) mGraph.numVertices() * 1.8));
		HashMap<Vertex<RoomCoordinate>, Edge<Walkway>> forest = new HashMap<>(
				(int) ((double) mGraph.numVertices() * 1.8));
		DoublyLinkedList<Edge<Walkway>> path = new DoublyLinkedList<>();

		Vertex<RoomCoordinate> strtVrt = null;
		Vertex<RoomCoordinate> endVrt = null;
		for (Vertex<RoomCoordinate> e : mGraph.vertices()) {

			if (e.getElement().compareTo(start) == 0) {
				strtVrt = e;
			}

			if (e.getElement().compareTo(end) == 0) {
				endVrt = e;
			}
		}

		if ((strtVrt == null) || (endVrt == null)) {
			return path;
		} else {
			DFS(mGraph, strtVrt, forest, visited);
		}

		if (forest.get(endVrt) == null) {
			return path;
		} else {
			return constructPath(strtVrt, endVrt, forest);
		}
	}

	public void DFS(Graph<RoomCoordinate, Walkway> graph, Vertex<RoomCoordinate> vert,
			HashMap<Vertex<RoomCoordinate>, Edge<Walkway>> forest, HashMap<Vertex<RoomCoordinate>, Boolean> visited) {

		visited.put(vert, true);

		Vertex<RoomCoordinate> north = null;
		Vertex<RoomCoordinate> east = null;
		Vertex<RoomCoordinate> south = null;
		Vertex<RoomCoordinate> west = null;

		for (Edge<Walkway> e : graph.outgoingEdges(vert)) {
			Vertex<RoomCoordinate> hold = graph.opposite(vert, e);

			if (hold.getElement().getX() == vert.getElement().getX()) {
				if (hold.getElement().getY() > vert.getElement().getY()) {
					south = hold;
				}
				if (hold.getElement().getY() < vert.getElement().getY()) {
					north = hold;
				}
			} else if (hold.getElement().getX() < vert.getElement().getX()) {
				west = hold;
			}
			if (hold.getElement().getX() > vert.getElement().getX()) {
				east = hold;
			}
		}

		if (north != null) {
			if (visited.get(north) == null) {
				forest.put(north, graph.getEdge(north, vert));
				DFS(graph, north, forest, visited);
			}
		}

		if (east != null) {
			if (visited.get(east) == null) {
				forest.put(east, graph.getEdge(east, vert));
				DFS(graph, east, forest, visited);
			}
		}

		if (south != null) {
			if (visited.get(south) == null) {
				forest.put(south, graph.getEdge(south, vert));
				DFS(graph, south, forest, visited);
			}
		}

		if (west != null) {
			if (visited.get(west) == null) {
				forest.put(west, graph.getEdge(west, vert));
				DFS(graph, west, forest, visited);
			}
		}
	}

	/**
	 * Complete the dfsPath function by implementing a Breadth First Search
	 * algorithm to find a path from start to end. At each vertex, the adjacent
	 * edges shall be searched in the order of NORTH, EAST, SOURTH and WEST.
	 * 
	 * @param start an RoomCoordinate object represents the start location, this
	 *              object does not exist in the graph
	 * @param end   an RoomCoordinate object represents the start location, this
	 *              object does not exist in the graph
	 * @return Return the sequence of edges traversed in order to get from the start
	 *         to the finish locations. If there is NO path, do NOT return null.
	 *         Return an empty sequence.
	 */
	@TimeComplexity("O( n + m )")
	public Iterable<Edge<Walkway>> bfsPath(RoomCoordinate start, RoomCoordinate end) {
		HashMap<Vertex<RoomCoordinate>, Boolean> visited = new HashMap<>((int) ((double) mGraph.numVertices() * 1.8));
		HashMap<Vertex<RoomCoordinate>, Edge<Walkway>> forest = new HashMap<>(
				(int) ((double) mGraph.numVertices() * 1.8));
		ArrayList<Vertex<RoomCoordinate>> queue = new ArrayList<>();
		DoublyLinkedList<Edge<Walkway>> path = new DoublyLinkedList<>();

		Vertex<RoomCoordinate> startV = null;
		Vertex<RoomCoordinate> endV = null;

		for (Vertex<RoomCoordinate> r : mGraph.vertices()) {
			if (r.getElement().compareTo(start) == 0) {
				startV = r;
			}
			if (r.getElement().compareTo(end) == 0) {
				endV = r;
			}
		}

		if ((startV == null) || (endV == null)) {
			return path;
		} else {
			BFS(mGraph, startV, visited, forest, queue);
		}

		if (forest.get(endV) == null) {
			return path;
		} else {
			return constructPath(startV, endV, forest);
		}
	}

	public void BFS(Graph<RoomCoordinate, Walkway> G, Vertex<RoomCoordinate> v,
			HashMap<Vertex<RoomCoordinate>, Boolean> visited, HashMap<Vertex<RoomCoordinate>, Edge<Walkway>> forest,
			ArrayList<Vertex<RoomCoordinate>> queue) {

		Vertex<RoomCoordinate> north = null;
		Vertex<RoomCoordinate> east = null;
		Vertex<RoomCoordinate> south = null;
		Vertex<RoomCoordinate> west = null;

		visited.put(v, true);
		queue.addLast(v);

		while (queue.size() > 0) {

			Vertex<RoomCoordinate> hold = queue.removeFirst();

			for (Edge<Walkway> e : G.outgoingEdges(hold)) {

				Vertex<RoomCoordinate> u = G.opposite(hold, e);

				if (u.getElement().getX() == hold.getElement().getX()) {

					if (u.getElement().getY() > hold.getElement().getY()) {

						south = u;
					}
					if (u.getElement().getY() < hold.getElement().getY()) {

						north = u;
					}
				} else if (u.getElement().getX() < hold.getElement().getX()) {

					west = u;
				}
				if (u.getElement().getX() > hold.getElement().getX()) {

					east = u;
				}
			}

			if (north != null) {

				if (visited.get(north) == null) {

					queue.addLast(north);
					visited.put(north, true);
					forest.put(north, G.getEdge(north, hold));
				}
			}

			if (east != null) {

				if (visited.get(east) == null) {

					queue.addLast(east);
					visited.put(east, true);
					forest.put(east, G.getEdge(east, hold));
				}
			}

			if (south != null) {

				if (visited.get(south) == null) {

					queue.addLast(south);
					visited.put(south, true);
					forest.put(south, G.getEdge(south, hold));
				}
			}

			if (west != null) {
				if (visited.get(west) == null) {
					queue.addLast(west);
					visited.put(west, true);
					forest.put(west, G.getEdge(west, hold));
				}
			}
		}
	}

	public UnorderedMap<Vertex<RoomCoordinate>, UnorderedMap<Vertex<RoomCoordinate>, Integer>> PathMap;

	/**
	 * Complete the shortestPath function by implementing Dijkstra's algorithm to
	 * find a path from start to end. At each vertex, the adjacent edges shall be
	 * searched in the order of NORTH, EAST, SOURTH and WEST.
	 * 
	 * @param start an RoomCoordinate object represents the start location, this
	 *              object does not exist in the graph
	 * @param end   an RoomCoordinate object represents the start location, this
	 *              object does not exist in the graph
	 * @return Return the sequence of edges traversed in order to get from the start
	 *         to the finish locations. If there is NO path, do NOT return null.
	 *         Return an empty sequence.
	 */
	@TimeComplexity("O( (n + m)log(m) )")
	public Iterable<Edge<Walkway>> shortestPath(RoomCoordinate start, RoomCoordinate end) {

		HashMap<Vertex<RoomCoordinate>, Integer> d = new HashMap<>();
		HeapPQ<Integer, Vertex<RoomCoordinate>> pq = new HeapPQ<>();
		HashMap<Vertex<RoomCoordinate>, Entry> pqTokens = new HashMap<>();
		HashMap<Vertex<RoomCoordinate>, Integer> cloud = new HashMap<>();
		HashMap<Vertex<RoomCoordinate>, Edge<Walkway>> forest = new HashMap<>();
		Vertex<RoomCoordinate> src = makeVertex(start);
		Vertex<RoomCoordinate> dst = makeVertex(end);

		for (Vertex<RoomCoordinate> u : mGraph.vertices()) {
			if (u.equals(src)) {
				d.put(u, 0);
			} else {
				d.put(u, Integer.MAX_VALUE);
			}
			pqTokens.put(u, pq.insert(d.get(u), u));
		}

		while (!pq.isEmpty()) {
			Entry<Integer, Vertex<RoomCoordinate>> entry = pq.removeMin();
			Integer key = entry.getKey();
			Vertex<RoomCoordinate> u = entry.getValue();

			if (u.equals(dst)) {
				break;
			}

			cloud.put(u, key);
			pqTokens.remove(u);
			ArrayList<Edge<Walkway>> sorted = pathConstructor(mGraph, u);
			for (Edge<Walkway> e : sorted) {
				Vertex<RoomCoordinate> w = mGraph.opposite(u, e);
				if (cloud.get(w) == null) {
					int newDistance = key + e.getElement().getDistance();
					if (d.get(w) > newDistance) {
						d.put(w, newDistance);
						forest.put(w, e);
						pq.replaceKey(pqTokens.get(w), newDistance);
					}
				}
			}

		}

		return constructPath(src, dst, forest);

	}

	private Vertex<RoomCoordinate> makeVertex(RoomCoordinate cord) {
		for (Vertex<RoomCoordinate> v : mGraph.vertices()) {
			if (v.getElement().compareTo(cord) == 0) {
				return v;
			}
		}
		return null;
	}

	private Iterable<Edge<Walkway>> constructPath(Vertex<RoomCoordinate> src, Vertex<RoomCoordinate> dst,
			HashMap<Vertex<RoomCoordinate>, Edge<Walkway>> forest) {
		DoublyLinkedList<Edge<Walkway>> path = new DoublyLinkedList<>();
		while (dst != src) {

			Edge<Walkway> E = forest.get(dst);
			path.addFirst(E);
			dst = mGraph.opposite(dst, E);
		}
		return path;
	}

	private ArrayList<Edge<Walkway>> pathConstructor(Graph<RoomCoordinate, Walkway> G, Vertex<RoomCoordinate> v) {
		ArrayList<Edge<Walkway>> store = new ArrayList<>();
		ArrayList<Edge<Walkway>> sorted = new ArrayList<>();
		for (Edge<Walkway> e : G.outgoingEdges(v)) {
			store.addLast(e);
		}

		// North
		for (int i = 0; i < store.size(); i++) {
			if (v.getElement().getY() > G.opposite(v, store.get(i)).getElement().getY()) {
				sorted.addLast(store.get(i));
			}
		}
		// East
		for (int i = 0; i < store.size(); i++) {
			if (v.getElement().getX() < G.opposite(v, store.get(i)).getElement().getX()) {
				sorted.addLast(store.get(i));
			}
		}
		// South
		for (int i = 0; i < store.size(); i++) {
			if (v.getElement().getY() < G.opposite(v, store.get(i)).getElement().getY()) {
				sorted.addLast(store.get(i));
			}
		}
		// West
		for (int i = 0; i < store.size(); i++) {
			if (v.getElement().getX() > G.opposite(v, store.get(i)).getElement().getX()) {
				sorted.addLast(store.get(i));
			}
		}
		return sorted;
	}

	/*
	 * Complete the totalPathDistance function, which calculates how far the given
	 * path traverses.
	 */
	@TimeComplexity("O(m)")
	public static double totalPathDistance(Iterable<Edge<Walkway>> path) {
		double total = 0.0;

		for (Edge<Walkway> e : path) {

			total += e.getElement().getDistance();
		}

		return total;
	}

	public static void main(String[] aArguments) {

		Labyrinth lLabyrinth = new Labyrinth("SmallLabyrinth.txt");

	}

}
