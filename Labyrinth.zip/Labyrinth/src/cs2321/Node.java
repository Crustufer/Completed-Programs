package cs2321;

import net.datastructures.Position;

public class Node<E> implements Position<E> {

    Node <E> prev;
    Node <E> next;
    E element;

    public Node( E e ) {
        element = e;
        prev = null;
        next = null;
    }

    public E getElement() throws IllegalStateException {
        if ( next == null ) { throw new IllegalStateException(); }
        return element;
    }

    public E setElement( E e ) {

        return element = e;

    }

        public Node<E> getPrevious() { return prev; }
        public Node<E> getNext() { return next; }
        public  void setPrevious( Node<E> n ) { prev = n; }
        public void setNext( Node<E> n ) { next = n; }


}
