package cs2321;

import net.datastructures.*;

/*
 * Implement Graph interface. A graph can be declared as either directed or undirected.
 * In the case of an undirected graph, methods outgoingEdges and incomingEdges return the same collection,
 * and outDegree and inDegree return the same value.
 * 
 * @author CS2321 Instructor
 */
@SpaceComplexity("O(n+m)")
public class AdjListGraph<V, E> implements Graph<V, E> {

	private DoublyLinkedList<Vertex<V>> vertices = new DoublyLinkedList<>( );
	private DoublyLinkedList<Edge<E>> edges = new DoublyLinkedList<>( );
	private boolean isDirected;

	public AdjListGraph(boolean directed) {
		isDirected = directed;
	}

	public AdjListGraph() {
		isDirected = false;
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#edges()
	 */
	@TimeComplexity("O(m)")
	public Iterable<Edge<E>> edges() {
		return edges;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#endVertices(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex[] endVertices(Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> edge = validateE(e);
		return edge.getEndpoints( );
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertEdge(net.datastructures.Vertex, net.datastructures.Vertex, java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Edge<E> insertEdge(Vertex<V> u, Vertex<V> v, E o)
			throws IllegalArgumentException {
		if (getEdge(u,v) == null) {
			InnerEdge<E> e = new InnerEdge<>(u, v, o);
			e.setPosition(edges.addLast(e));
			InnerVertex<V> origin = validateV(u);
			InnerVertex<V> dest = validateV(v);
			origin.getOutgoing( ).put(v, e);
			dest.getIncoming( ).put(u, e);
			return e;
		} else {
			throw new IllegalArgumentException();
		}
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertVertex(java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> insertVertex(V o) {
		InnerVertex<V> v = new InnerVertex<>( o, isDirected);
		v.setPosition(vertices.addLast(v));
		return v;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numEdges()
	 */
	@TimeComplexity("O(1)")
	public int numEdges() {
		return edges.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numVertices()
	 */
	@TimeComplexity("O(1)")
	public int numVertices() {
		return vertices.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#opposite(net.datastructures.Vertex, net.datastructures.Edge)
	 */
	public Vertex<V> opposite(Vertex<V> v, Edge<E> e)
			throws IllegalArgumentException {
		InnerEdge<E> edge = validateE(e);
		Vertex<V>[ ] endpoints = edge.getEndpoints( );
		if (endpoints[0] == v)
			return endpoints[1];
		else if (endpoints[1] == v)
			return endpoints[0];
		else
			throw new IllegalArgumentException();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeEdge(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public void removeEdge(Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> inEd = validateE(e);
		Vertex<V>[] array = inEd.endpoints;
		InnerVertex<V> vertex1 = validateV( array[0] );
		InnerVertex<V> vertex2 = validateV( array[1] );
		vertex1.getOutgoing().remove( vertex2 );
		vertex2.getIncoming().remove( vertex1 );
		edges.remove( inEd.getPosition() );
		inEd.setPosition( null );
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeVertex(net.datastructures.Vertex)
	 */
	@TimeComplexity("O(deg(v))")
	public void removeVertex(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validateV(v);
		// remove all incident edges from the graph
		for (Edge<E> e : vert.getOutgoing( ).values( ))
			removeEdge(e);
		for (Edge<E> e : vert.getIncoming( ).values( ))
			removeEdge(e);
		// remove this vertex from the list of vertices
		vertices.remove(vert.getPosition( ));
	
	}

	/* 
     * replace the element in edge object, return the old element
     */
	public E replace(Edge<E> e, E o) throws IllegalArgumentException {
		InnerEdge<E> inEd = validateE( e );
		E temp = inEd.getElement();
		Vertex<V>[] array = inEd.endpoints;
		removeEdge( inEd );
		insertEdge( array[0],array[1], o );
		return temp;
	}

    /* 
     * replace the element in vertex object, return the old element
     */
	public V replace(Vertex<V> v, V o) throws IllegalArgumentException {
		InnerVertex<V> vertex = validateV( v );
		V temp = v.getElement();
		Vertex<V> vertex1 = insertVertex( o );
		for ( Edge<E> edge : vertex.getOutgoing().values() ) {
			insertEdge( opposite(vertex, edge ), vertex1, edge.getElement() );
		}
		for ( Edge<E> edge : vertex.getIncoming().values() ) {
			insertEdge( opposite(vertex, edge ), vertex1, edge.getElement() );
		}
		removeVertex( vertex );
		return temp;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#vertices()
	 */
	public Iterable<Vertex<V>> vertices() {
		return vertices;
	}

	@TimeComplexity("O(1)")
	@Override
	public int outDegree(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validateV(v);
		return vert.getOutgoing( ).size( );
	}

	@TimeComplexity("O(1)")
	@Override
	public int inDegree(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validateV(v);
		return vert.getIncoming( ).size( );

	}

	@TimeComplexity("O(deg(v))")
	@Override
	public Iterable<Edge<E>> outgoingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> vert = validateV(v);
		return vert.getOutgoing( ).values( );
	}

	@TimeComplexity("O(deg(v))")
	@Override
	public Iterable<Edge<E>> incomingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> vert = validateV(v);
		return vert.getIncoming( ).values( );
	}

	@TimeComplexity("O(1)")
	@Override
	public Edge<E> getEdge(Vertex<V> u, Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> origin = validateV(u);
		return origin.getOutgoing( ).get(v);
	}

	private class InnerVertex<V> implements Vertex<V> {
		private V element;
		private Position<Vertex<V>> pos;
		private Map<Vertex<V>, Edge<E>> outgoing, incoming;

		public InnerVertex(V elem, boolean graphIsDirected) {
			element = elem;
			outgoing = new HashMap<>();
			if (graphIsDirected)
				incoming = new HashMap<>();
			else
				incoming = outgoing;
		}

		public V getElement () {
			return element;
		}

		public void setPosition (Position < Vertex < V >> p) {
			pos = p;
		}

		public Position<Vertex<V>> getPosition () {
			return pos;
		}

		public Map<Vertex<V>, Edge<E>> getOutgoing () {
			return outgoing;
		}

		public Map<Vertex<V>, Edge<E>> getIncoming () {
			return incoming;
		}
	}

	private class InnerEdge<E> implements Edge<E> {
		private E element;
		private Position<Edge<E>> pos;
		private Vertex<V>[ ] endpoints;

		public InnerEdge(Vertex<V> u, Vertex<V> v, E elem) {
			element = elem;
			endpoints = (Vertex<V>[]) new Vertex[]{u, v}; // array of length 2
		}

		public E getElement( ) { return element; }

		public Vertex<V>[ ] getEndpoints( ) { return endpoints; }

		public void setPosition(Position<Edge<E>> p) { pos = p; }

		public Position<Edge<E>> getPosition( ) { return pos; }
	}

	private InnerVertex<V> validateV( Vertex<V> v ) throws IllegalArgumentException{
		if( !(v instanceof Vertex )) throw new IllegalArgumentException();
		InnerVertex<V> vertex = (InnerVertex<V>) v;
		return vertex;
	}

	private InnerEdge<E> validateE( Edge<E> e ) throws IllegalArgumentException{
		if( !(e instanceof Edge )) throw new IllegalArgumentException();
		InnerEdge<E> edge = (InnerEdge<E>) e;
		return edge;
	}
	
}
